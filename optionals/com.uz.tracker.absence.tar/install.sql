ALTER TABLE wcf1_user_tracker ADD profileAbsence TINYINT(1) NOT NULL DEFAULT 1;
