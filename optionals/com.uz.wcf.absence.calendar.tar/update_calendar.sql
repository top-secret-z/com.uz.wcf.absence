ALTER TABLE calendar1_event ADD absentUserID INT(10);
